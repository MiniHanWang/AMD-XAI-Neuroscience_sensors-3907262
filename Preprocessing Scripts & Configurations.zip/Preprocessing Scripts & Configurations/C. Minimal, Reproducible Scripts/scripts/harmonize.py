# scripts/harmonize.py
import os, json, yaml, glob, logging, logging.config
from pathlib import Path
import pandas as pd

def load_yaml(p): 
    with open(p,"r",encoding="utf-8") as f: 
        return yaml.safe_load(f)

def main(cfg_path):
    cfg = load_yaml(cfg_path)
    if os.path.exists(cfg["logging"]["config_file"]):
        logging.config.fileConfig(cfg["logging"]["config_file"])
    log = logging.getLogger("harmonize")

    tables_dir = Path(cfg["paths"]["processed_tables_dir"]); tables_dir.mkdir(parents=True, exist_ok=True)

    # Text features
    text_df = pd.read_parquet(tables_dir / "text_features.parquet")

    # Imaging sidecars → imaging features stub
    sidecars = []
    for fp in glob.glob(os.path.join(cfg["paths"]["interim_sidecar_dir"], "*.json")):
        with open(fp,"r",encoding="utf-8") as f:
            sc = json.load(f)
        # Expect schema_key to encode study_id, eye, timepoint; if not, split accordingly in your naming rule
        sidecars.append({
            "schema_key": sc["schema_key"],
            "modality": sc["modality"],
            "snr": sc["snr"],
            "snr_pass": sc["snr_pass"],
            "fov_pass": sc["fov_pass"],
            "motion_pass": sc["motion_pass"],
            "software_version": sc["device"]["software_version"]
        })
    img_df = pd.DataFrame(sidecars)

    # Outcomes placeholder: assemble from text_json (or a dedicated outcomes source)
    # For demo, assume outcomes are stored inside text_json with keys like bcva_change, fluid_resolution, complications
    outcome_rows = []
    for fp in glob.glob(os.path.join(cfg["paths"]["interim_text_json_dir"], "*.json")):
        with open(fp,"r",encoding="utf-8") as f:
            d = json.load(f)
        outcome_rows.append({
            "schema_key": d["schema_key"],
            "bcva_change": d.get("bcva_change"),
            "fluid_resolution": d.get("fluid_resolution"),
            "complications": d.get("complications"),
            "readout_time": d.get("timepoint")
        })
    out_df = pd.DataFrame(outcome_rows)

    # Save harmonized tables
    text_df.to_parquet(tables_dir / "text_features.parquet", index=False)
    img_df.to_parquet(tables_dir / "imaging_features.parquet", index=False)
    out_df.to_parquet(tables_dir / "outcomes.parquet", index=False)
    log.info("Saved harmonized tables: text_features, imaging_features, outcomes.")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/preprocessing.yml")
    args = ap.parse_args()
    main(args.config)
