# scripts/image_qc_export.py
import os, json, glob, yaml, logging, logging.config
from pathlib import Path
import numpy as np
import pandas as pd
import pydicom
from PIL import Image

def load_yaml(p): 
    with open(p,"r",encoding="utf-8") as f: 
        return yaml.safe_load(f)

def snr_estimate(img):
    # Simple robust SNR proxy: mean / std in central ROI (placeholder)
    h, w = img.shape
    roi = img[h//4:3*h//4, w//4:3*w//4]
    m, s = float(np.mean(roi)), float(np.std(roi) + 1e-6)
    return m / s

def expected_fov_ok(ds, expected):
    # Check PixelSpacing × image dimensions ~ expected FOV (mm)
    try:
        ps = [float(x) for x in ds.PixelSpacing]  # mm/pixel
        mm_x = ps[1] * int(ds.Columns)
        mm_y = ps[0] * int(ds.Rows)
        ex, ey = expected
        return abs(mm_x - ex) < 0.6 and abs(mm_y - ey) < 0.6
    except Exception:
        return True  # if unknown, don't fail hard

def main(cfg_path):
    cfg = load_yaml(cfg_path)
    if os.path.exists(cfg["logging"]["config_file"]):
        logging.config.fileConfig(cfg["logging"]["config_file"])
    log = logging.getLogger("image_qc")

    raw_dir = Path(cfg["paths"]["raw_dicom_dir"])
    png_dir = Path(cfg["paths"]["interim_png_dir"]); png_dir.mkdir(parents=True, exist_ok=True)
    side_dir = Path(cfg["paths"]["interim_sidecar_dir"]); side_dir.mkdir(parents=True, exist_ok=True)
    qc_dir = Path(cfg["paths"]["qc_report_dir"]); qc_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for dcm_fp in glob.glob(str(raw_dir / "**/*.dcm"), recursive=True):
        try:
            ds = pydicom.dcmread(dcm_fp)
            # Basic anonymization of key tags (if any present)
            for tag in cfg["deidentification"]["dicom_tags_remove"]:
                if tag in ds: del ds[tag]

            modality = getattr(ds, "Modality", "UNK")
            px = ds.pixel_array.astype(np.float32)
            # Normalize to 0-255
            px_norm = (px - px.min()) / (px.ptp() + 1e-6)
            img8 = (px_norm * 255).clip(0,255).astype(np.uint8)

            # QC checks
            snr_thr = cfg["imaging"]["snr_thresholds"].get(modality, 0.0)
            snr = snr_estimate(img8)

            fov_ok = True
            if modality == "OCT" and "OCT" in cfg["imaging"]["expected_fov_mm"]:
                fov_ok = expected_fov_ok(ds, cfg["imaging"]["expected_fov_mm"]["OCT"])

            # Placeholder: motion check (if Manufacturer data not available)
            motion_flag = False
            if modality == "OCT":
                # Simple heuristic: count saturated horizontal lines
                diffs = np.mean(np.abs(np.diff(img8, axis=1)), axis=1)
                motion_lines = np.sum(diffs > (np.mean(diffs) + 3*np.std(diffs)))
                pct = 100.0 * motion_lines / img8.shape[0]
                motion_flag = pct > cfg["imaging"]["motion_threshold_oct_percent"]

            # Export PNG + sidecar
            schema_key = Path(dcm_fp).stem  # assume filename already equals StudyID–Eye–Time–Modality–uid
            if cfg["imaging"]["export_png"]:
                png_fp = png_dir / f"{schema_key}.png"
                Image.fromarray(img8).save(png_fp)

            side = {
                "schema_key": schema_key,
                "modality": modality,
                "columns": int(getattr(ds,"Columns",img8.shape[1])),
                "rows": int(getattr(ds,"Rows",img8.shape[0])),
                "pixel_spacing": [float(x) for x in getattr(ds,"PixelSpacing", [np.nan,np.nan])],
                "snr": snr,
                "snr_pass": snr >= snr_thr,
                "fov_pass": bool(fov_ok),
                "motion_pass": not motion_flag,
                "device": {
                    "manufacturer": str(getattr(ds,"Manufacturer","")),
                    "model": str(getattr(ds,"ManufacturerModelName","")),
                    "software_version": str(getattr(ds,"SoftwareVersions",""))
                }
            }
            with open(side_dir / f"{schema_key}.json","w",encoding="utf-8") as fw:
                json.dump(side, fw, ensure_ascii=False, indent=2)

            rows.append({
                "schema_key": schema_key, "modality": modality,
                "snr": snr, "snr_thr": snr_thr,
                "snr_pass": side["snr_pass"], "fov_pass": side["fov_pass"],
                "motion_pass": side["motion_pass"]
            })

        except Exception as e:
            logging.exception(f"Failed {dcm_fp}")

    df = pd.DataFrame(rows)
    df.to_csv(qc_dir / "imaging_qc_summary.csv", index=False)
    log.info(f"QC summary saved: {qc_dir/'imaging_qc_summary.csv'} with {len(df)} rows.")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/preprocessing.yml")
    args = ap.parse_args()
    main(args.config)
