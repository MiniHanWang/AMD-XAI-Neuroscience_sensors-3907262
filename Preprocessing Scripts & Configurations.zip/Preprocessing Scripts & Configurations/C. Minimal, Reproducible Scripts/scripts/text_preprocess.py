# scripts/text_preprocess.py
import os, json, hashlib, yaml, logging, re, glob
import pandas as pd
import spacy
from pathlib import Path
from datetime import datetime
from negspacy.negation import Negex
import logging.config

def load_yaml(p): 
    with open(p, "r", encoding="utf-8") as f: 
        return yaml.safe_load(f)

def hash_value(x, salt):
    if not x: return None
    return hashlib.sha256((str(x)+salt).encode("utf-8")).hexdigest()[:12]

def normalize_dates(text):
    # normalize common date patterns to ISO 8601 when possible (simple demo)
    text = re.sub(r"(\d{4})[/-](\d{1,2})[/-](\d{1,2})", r"\1-\2-\3", text)
    return text

def main(cfg_path):
    cfg = load_yaml(cfg_path)
    if os.path.exists(cfg["logging"]["config_file"]):
        logging.config.fileConfig(cfg["logging"]["config_file"])
    log = logging.getLogger("text_preprocess")

    nlp = spacy.load(cfg["text"]["language_model"])
    nlp.add_pipe("sentencizer")
    nlp.add_pipe("negex", config={"chunk_prefix": ["no","without","denies"]})
    # Add custom tokenizer rules
    for t in cfg["text"]["custom_terms"]:
        nlp.tokenizer.add_special_case(t, [{spacy.symbols.ORTH: t}])

    out_dir = Path(cfg["paths"]["interim_text_json_dir"]); out_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for fp in glob.glob(os.path.join(cfg["paths"]["raw_text_dir"], "*.json")):
        with open(fp, "r", encoding="utf-8") as f:
            doc = json.load(f)
        # Basic structure assumed: {study_id, eye, timepoint, text, mrn, name, phone, address, dob}
        salt = cfg["deidentification"]["hash_salt"]
        for fld in cfg["deidentification"]["text_fields_hash"]:
            if fld in doc:
                doc[fld] = hash_value(doc.get(fld), salt)

        text = normalize_dates(doc.get("text",""))
        text = re.sub(r"\s+", " ", text).strip()

        spacy_doc = nlp(text)
        ents = []
        for e in spacy_doc.ents:
            ents.append({
                "text": e.text, "label": e.label_,
                "start_char": e.start_char, "end_char": e.end_char,
                "is_negated": getattr(e._, "negex", False)
            })

        normalized = {
            "study_id": doc["study_id"],
            "eye": doc["eye"],
            "timepoint": doc["timepoint"],
            "schema_key": cfg["keys"]["schema_pattern"].format(
                study_id=doc["study_id"], eye=doc["eye"], timepoint=doc["timepoint"]
            ),
            "text": text,
            "entities": ents,
            # Stub concept mapping: replace with your actual terminology service
            "concept_ids": [], 
            "negation_flags": any(x["is_negated"] for x in ents),
            "areds_stage": doc.get("areds_stage"),
            "treatment_lines": doc.get("treatment_lines"),
        }

        out_fp = out_dir / f'{normalized["schema_key"]}.json'
        with open(out_fp, "w", encoding="utf-8") as fw:
            json.dump(normalized, fw, ensure_ascii=False, indent=2)

        rows.append({
            "schema_key": normalized["schema_key"],
            "study_id": normalized["study_id"],
            "eye": normalized["eye"],
            "timepoint": normalized["timepoint"],
            "negation_flags": normalized["negation_flags"],
            "areds_stage": normalized["areds_stage"],
            "treatment_lines": normalized["treatment_lines"]
        })

    df = pd.DataFrame(rows)
    tables_dir = Path(cfg["paths"]["processed_tables_dir"]); tables_dir.mkdir(parents=True, exist_ok=True)
    df.to_parquet(tables_dir / "text_features.parquet", index=False)
    log.info(f"Saved text_features.parquet with {len(df)} rows.")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config/preprocessing.yml")
    args = ap.parse_args()
    main(args.config)
